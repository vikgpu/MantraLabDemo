//
//  ViewController.swift
//  MantraLabDemo
//
//  Created by Vikas Gupta on 17/03/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var expandTableview: UITableView!
    var sections = [Section]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        expandTableview.estimatedRowHeight = 44.0
        expandTableview.rowHeight = UITableView.automaticDimension
        getDataFromApi()
    }
    
    func getDataFromApi(){
        
        let servicesManager = ServiceManager()
        servicesManager.servicegetParam(backView: view,ServiesType:"menu") { (response, isSuccess) in
            do {
                let json = try! JSONSerialization.jsonObject(with: response) as! [JSONDictionary]
                self.sections = json.flatMap(Section.init)
                self.expandTableview.reloadData()
               
            }
            catch let err{
                print(err)
            }
        }
    }


}

extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].collapsed ? 0 : sections[section].items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: ExpandTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as? ExpandTableViewCell ??
            ExpandTableViewCell(style: .default, reuseIdentifier: "cell")
        
        let item: Item = sections[indexPath.section].items[indexPath.row]
        
        cell.nameLabel.text = item.name
        cell.detailLabel.text = item.detail
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "header") as? ExpandTableViewHeader ?? ExpandTableViewHeader(reuseIdentifier: "header")
        
        header.titleLabel.text = sections[section].name
        header.arrowLabel.text = ">"
        header.setCollapsed(sections[section].collapsed)
        
        header.section = section
        header.delegate = self
        
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    
}
extension ViewController: ExpandTableViewHeaderDelegate {
    
    func toggleSection(_ header: ExpandTableViewHeader, section: Int) {
        let collapsed = !sections[section].collapsed
        
        // Toggle collapse
        sections[section].collapsed = collapsed
        header.setCollapsed(collapsed)
        
        expandTableview.reloadSections(NSIndexSet(index: section) as IndexSet, with: .automatic)
    }
    
}


