//
//  ExpandTableViewCell.swift
//  MantraLabDemo
//
//  Created by Vikas Gupta on 17/03/21.
//

import Foundation

//
// MARK: - Section Data Structure
//
class Item {
    var name: String
    var detail: String
    
     init?(dictionary : JSONDictionary) {
        guard let name = dictionary["name"] as? String,
              let detail = dictionary["display_name"] as? String else {
                 return nil
        }
        self.name = name
        self.detail = detail
    }
}
class Section {
    var name: String
    var items: [Item]
    var collapsed: Bool
    
    
    init?(dictionary : JSONDictionary) {
        guard let name = dictionary["name"] as? String,
              let items = dictionary["sub_category"] as? [JSONDictionary],
              let collapsed = true as? Bool else{
                 return nil
             }
        
        self.name = name
        self.items = items.flatMap(Item.init)
        self.collapsed = collapsed
    }
    

}

