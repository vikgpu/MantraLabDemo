//
//  ServiceManager.swift
//  MantraLabDemo
//
//  Created by Vikas Gupta on 17/03/21.
//

import UIKit

typealias JSONDictionary = [String:Any]

class ServiceManager: NSObject {
    
    func servicegetParam( backView: UIView,ServiesType:String, serviceHandler:@escaping (Data, Bool)->Void){
        
        if let path = Bundle.main.path(forResource: ServiesType, ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .alwaysMapped)
        
                DispatchQueue.main.async() { () -> Void in
                
                    serviceHandler(data , false)
                }
                
            } catch let error {
                print("parse error: \(error.localizedDescription)")
            }
        } else {
            print("Invalid filename/path.")
        }
        
    }

}
